/*
      multiline
      comments
*/

// Boolean
console.log(true, false)
console.log("true and false", true && false)
console.log("true or false", true || false)
console.log("not true", !true)

// Numbers
console.log("25 * 5 =", 25 * 5);
console.log("25 / 5 =", 25 / 5);
console.log("25 + 5 =", 25 + 5);
console.log("25 - 5 =", 25 - 5);
console.log("25 % 4 =", 25 % 4);
console.log("5 <= 6 ", 5 <= 6);
console.log("5 === 6 ", 5 === 6);
console.log("5 !== 6", 5 !== 6);

//String
let s1 = "Hello, "
let s2 = 'World!'
const s3 = s1 +  s2
console.log(s3)
// Object
const o1 = { fname: "Jone", lname: "Doe", age: 18}
o1.age = 19
console.log("fname is ", o1.fname, ". Age is", o1["age"])
// List
const l1 = ["Jone", "Bob", "Kate"]
console.log("n =", l1.length, "Name is ", li[0])
// Function
console.log("addNum(5, 6)=" , addNum(5, 6))
const add = (a, b) => { return a + b;}
console.log("add(5, 6)=", add(5, 6));

function addNum(a, b))
{
    let х = a + b;
    return x;
}
// Control flow
let x = 5;
if(x < 0)
{
    console.log("x is negative")
}
else if (x === 0)
{
    console.log("x is zero")
}
else 
    console.log("x iz pozitive");
    
// while(test){}

for(let i = 0; i < l1.length; i++)
{
    console.log(l1[i])
}

for (const elem of l1)
    console.log(elem)
// Variables
const pi = 3.14
let v1 = 2
v1 = 3
console.log("v1 =", v1)
// pi = 4.14